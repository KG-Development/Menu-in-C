#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include "menu.h"
#include "myconio.h"

int main()
{
    TMenu menu = {0};
    char key;

    menu.Bc = BLACK;
    menu.Fc = GREEN;

    setHeader(&menu.headerFooter, "T E S T  H E A D E R");
    setFooter(&menu.headerFooter, "T E S T  F O O T E R");

    addField(&menu, GREEN, BLACK, 's', "to Start");
    addField(&menu, GREEN, BLACK, 'e', "to close");

    printMenu(&menu);
    key = inputMenu(&menu);

    if(key == 's'){
        system("cls");
        printf("S T A R T ...");
        getch();
    }else if(key == 'e'){

        system("cls");
        printf("E N D ...");
        getch();
    }

    system("cls");
    printf("Thanks\n");

    return 0;
}
